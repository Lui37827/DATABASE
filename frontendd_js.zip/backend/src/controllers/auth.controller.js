const jwt = require('jsonwebtoken');

async function login(req, res) {
  try {
    // 1. Obtener datos del body
    const { email, password } = req.body;

    // Simulación de usuario validado
    const usuario = {
      id: 1,
      nombre: 'Usuario Demo',
      email: email,
      rol: 'admin'
    };

    // 2. Generar el token JWT que el frontend guardará
    const token = jwt.sign(
      {
        id: usuario.id,
        email: usuario.email,
        rol: usuario.rol
      },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    // 3. Responder con el token y los datos públicos del usuario
    return res.status(200).json({
      token,
      usuario: {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
        rol: usuario.rol
      }
    });

  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}

module.exports = {
  login
};